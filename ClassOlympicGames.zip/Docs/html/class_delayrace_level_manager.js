var class_delayrace_level_manager =
[
    [ "Score", "class_delayrace_level_manager.html#a440cdf61e960d35827845c2a354db04d", null ],
    [ "WAIT_SECS", "class_delayrace_level_manager.html#ab7e4ebc2d9ed5324150990621b2e0d01", null ]
];