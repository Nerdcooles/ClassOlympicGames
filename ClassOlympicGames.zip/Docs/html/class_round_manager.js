var class_round_manager =
[
    [ "NextRound", "class_round_manager.html#a85d045181fd1b61213f06839d065c018", null ],
    [ "Reset", "class_round_manager.html#a6c6f7c590da7d161d6104f3a72e68017", null ],
    [ "Image", "class_round_manager.html#aadf0312f3ddab3120d4fde3db14fd04e", null ],
    [ "Round", "class_round_manager.html#a04319242802c98bd953aacc8b55f5bb1", null ]
];