var class_longboard_player =
[
    [ "Initialize", "class_longboard_player.html#ab62fc99d931b7ff1990ee461ddf4832c", null ],
    [ "OnStart", "class_longboard_player.html#a7de1fe0d86300d6b02259ebff2c0a713", null ],
    [ "Pressed", "class_longboard_player.html#ab5d705c9a3aede9d54468f7d27ca9b0c", null ],
    [ "Released", "class_longboard_player.html#add0b615dfd9a60697959906d729c4499", null ],
    [ "red_line", "class_longboard_player.html#a790b6b06ff125f0e409541160f4d1bbb", null ]
];