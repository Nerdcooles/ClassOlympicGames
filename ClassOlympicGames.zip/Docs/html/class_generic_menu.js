var class_generic_menu =
[
    [ "Back", "class_generic_menu.html#aa56ce5652cd44af27cef808a2fbd740d", null ],
    [ "Exit", "class_generic_menu.html#a9caf8a7af7657aae2a2280d14147c56e", null ]
];