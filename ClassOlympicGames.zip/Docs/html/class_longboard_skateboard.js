var class_longboard_skateboard =
[
    [ "player", "class_longboard_skateboard.html#a2b68a29100f75afe5d95d1700445b1af", null ]
];