var dir_486b2703c5d661189a8846908289434d =
[
    [ "Nerd.cs", "_nerd_8cs.html", [
      [ "Nerd", "class_nerd.html", "class_nerd" ]
    ] ],
    [ "NerdLevelManager.cs", "_nerd_level_manager_8cs.html", [
      [ "NerdLevelManager", "class_nerd_level_manager.html", "class_nerd_level_manager" ]
    ] ],
    [ "NerdPlayer.cs", "_nerd_player_8cs.html", [
      [ "NerdPlayer", "class_nerd_player.html", "class_nerd_player" ]
    ] ]
];