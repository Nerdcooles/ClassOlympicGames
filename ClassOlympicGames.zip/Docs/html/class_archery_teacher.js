var class_archery_teacher =
[
    [ "EndHitted", "class_archery_teacher.html#af2c609aa943cd8420163be3025333bb5", null ],
    [ "Hitted", "class_archery_teacher.html#a41c3f548d1db72065d3ad51caf98cd95", null ]
];