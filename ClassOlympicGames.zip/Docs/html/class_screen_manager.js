var class_screen_manager =
[
    [ "getButton", "class_screen_manager.html#a85743d1875889b0b23ce7fe2bc5a793c", null ],
    [ "score", "class_screen_manager.html#a3fe9fb2fa503e68c4817dde96215216e", null ],
    [ "SceneHeight", "class_screen_manager.html#a79fc29ae758d03bcaff719f88385ebb1", null ],
    [ "SceneWidth", "class_screen_manager.html#acc069fc58ffe111de2b467ae247bd339", null ]
];