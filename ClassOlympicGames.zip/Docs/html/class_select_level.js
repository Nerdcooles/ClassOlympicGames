var class_select_level =
[
    [ "startArchery", "class_select_level.html#ad6dabba096c318e0fd03628888ed19c0", null ],
    [ "startBucket", "class_select_level.html#a1cf6cc3e81db6c60df56716e512b4368", null ],
    [ "startBus", "class_select_level.html#ad0545d5ce2b72514dfb656b1afd3de80", null ],
    [ "startLongboard", "class_select_level.html#ad27a722b1d473913ae941c4cdcc6c285", null ],
    [ "startNerd", "class_select_level.html#ad34da5a7e02239cf5c8e9e13f82cb77b", null ],
    [ "startSkip", "class_select_level.html#afd7a585de5e9a60cf45f14a8cfbc970b", null ]
];