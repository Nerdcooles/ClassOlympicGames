var class_select_mode =
[
    [ "StartClassic", "class_select_mode.html#aef126e169324a939bfbd1b9b3e63c340", null ],
    [ "StartTraining", "class_select_mode.html#acf551d48dbb362cc801f48c9c3369526", null ]
];