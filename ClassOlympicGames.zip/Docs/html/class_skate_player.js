var class_skate_player =
[
    [ "Initialize", "class_skate_player.html#a7274a3556c5e4754e80d30264211de3e", null ],
    [ "Pressed", "class_skate_player.html#afe0a6ebbba01adc46e079a7b9db6aac6", null ],
    [ "Released", "class_skate_player.html#aa9cb878bd487b9604d4dc0ef9d55e2ab", null ],
    [ "StartPlayer", "class_skate_player.html#a5b1235d79f2ae84a7597db37678f7dc7", null ],
    [ "red_line", "class_skate_player.html#a8732325e7ba61aec52ce42a029199b8c", null ]
];