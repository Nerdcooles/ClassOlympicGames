var dir_f180fe51350bae27be14275a825c71cb =
[
    [ "LongboardLevelManager.cs", "_longboard_level_manager_8cs.html", [
      [ "LongboardLevelManager", "class_longboard_level_manager.html", "class_longboard_level_manager" ]
    ] ],
    [ "LongboardPlayer.cs", "_longboard_player_8cs.html", [
      [ "LongboardPlayer", "class_longboard_player.html", "class_longboard_player" ]
    ] ],
    [ "LongboardSkateboard.cs", "_longboard_skateboard_8cs.html", [
      [ "LongboardSkateboard", "class_longboard_skateboard.html", "class_longboard_skateboard" ]
    ] ]
];