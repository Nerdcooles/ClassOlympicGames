var class_long_level_manager =
[
    [ "Score", "class_long_level_manager.html#a22067f493a789ff99fd086e8c7c1b0b4", null ]
];