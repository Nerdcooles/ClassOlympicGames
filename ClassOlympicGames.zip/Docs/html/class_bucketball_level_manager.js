var class_bucketball_level_manager =
[
    [ "Score", "class_bucketball_level_manager.html#a67dd3ace9b3349cbde3f68f4882c6827", null ]
];