var searchData=
[
  ['camera2dfollow',['Camera2DFollow',['../class_camera2_d_follow.html',1,'']]],
  ['camera2dfollow_2ecs',['Camera2DFollow.cs',['../_camera2_d_follow_8cs.html',1,'']]],
  ['classic',['CLASSIC',['../class_game_manager.html#a32bad955cacaf4ec060cabc5af66cca2a21994d6177b29e1128b2d7f0f8342057',1,'GameManager']]],
  ['color',['color',['../class_player_character.html#a43d749c1e7556ec2d6d6d326ef739d07',1,'PlayerCharacter.color()'],['../class_player.html#a8c7177a16a2f23362d8f0e58aef2d152',1,'Player.Color()'],['../class_player_character.html#aab84c1edefa41827be0e5946fd735e43',1,'PlayerCharacter.Color()']]],
  ['continue',['Continue',['../class_pause.html#afc9114b137ef0f1d58d5b3a0b28d006e',1,'Pause']]],
  ['countdown',['Countdown',['../class_level_manager.html#a2da83551e2c74b7358377ae9469c8059ae64465da4a42d65847b321045b155602',1,'LevelManager']]],
  ['createplayers',['CreatePlayers',['../class_game_manager.html#ac6f860a5e5fbc377080f49abd295ef53',1,'GameManager']]],
  ['credits',['Credits',['../class_credits.html',1,'Credits'],['../class_home.html#a2a7194ab46e0816bf14f08aa1bb38aed',1,'Home.Credits()'],['../class_menu_manager.html#a31aa0a50fb627a085a1adfa8170238ba',1,'MenuManager.Credits()']]],
  ['credits_2ecs',['Credits.cs',['../_credits_8cs.html',1,'']]],
  ['currentmenu',['CurrentMenu',['../class_game_manager.html#a52b240dd4a4b27ee796e48781b150741',1,'GameManager']]]
];
