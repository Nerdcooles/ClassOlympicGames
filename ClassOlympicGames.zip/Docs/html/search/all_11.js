var searchData=
[
  ['wait_5fsecs',['WAIT_SECS',['../class_delayrace_level_manager.html#ab7e4ebc2d9ed5324150990621b2e0d01',1,'DelayraceLevelManager.WAIT_SECS()'],['../class_skipthetest_level_manager.html#ad9d75ea2cb7c038e35c4861218031303',1,'SkipthetestLevelManager.WAIT_SECS()']]],
  ['withround',['withRound',['../class_level_manager.html#a81034f214facb2c34a6f1d676feccc4f',1,'LevelManager']]]
];
