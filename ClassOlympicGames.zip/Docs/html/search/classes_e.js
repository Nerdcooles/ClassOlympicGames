var searchData=
[
  ['roundmanager',['RoundManager',['../class_round_manager.html',1,'']]]
];
