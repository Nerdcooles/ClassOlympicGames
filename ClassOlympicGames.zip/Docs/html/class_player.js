var class_player =
[
    [ "Player", "class_player.html#a712a726b07cf901c040116d6d0c5cc66", null ],
    [ "AddMedal", "class_player.html#a5c922141313a733afa6d9c452f44ba7e", null ],
    [ "GetMedals", "class_player.html#a466e1bc0db92c4705932685ade1f94fd", null ],
    [ "Color", "class_player.html#a8c7177a16a2f23362d8f0e58aef2d152", null ],
    [ "Number", "class_player.html#a62db9602b1481ac60257702fdbbfadde", null ],
    [ "Points", "class_player.html#a543909f193394b106fedb6cc7f90c3b8", null ]
];