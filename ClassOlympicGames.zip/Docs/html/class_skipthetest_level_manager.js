var class_skipthetest_level_manager =
[
    [ "Score", "class_skipthetest_level_manager.html#aa06b6dfd068cce82ef6669af9f2c1448", null ],
    [ "WAIT_SECS", "class_skipthetest_level_manager.html#ad9d75ea2cb7c038e35c4861218031303", null ]
];