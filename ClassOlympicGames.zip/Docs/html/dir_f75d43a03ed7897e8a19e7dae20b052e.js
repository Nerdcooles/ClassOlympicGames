var dir_f75d43a03ed7897e8a19e7dae20b052e =
[
    [ "Camera2DFollow.cs", "_camera2_d_follow_8cs.html", [
      [ "Camera2DFollow", "class_camera2_d_follow.html", null ]
    ] ],
    [ "MedalMovement.cs", "_medal_movement_8cs.html", [
      [ "MedalMovement", "class_medal_movement.html", "class_medal_movement" ]
    ] ],
    [ "OffScreenFace.cs", "_off_screen_face_8cs.html", [
      [ "OffScreenFace", "class_off_screen_face.html", "class_off_screen_face" ]
    ] ],
    [ "Player.cs", "_player_8cs.html", [
      [ "Player", "class_player.html", "class_player" ]
    ] ],
    [ "PlayerCharacter.cs", "_player_character_8cs.html", [
      [ "PlayerCharacter", "class_player_character.html", "class_player_character" ]
    ] ],
    [ "Singleton.cs", "_singleton_8cs.html", [
      [ "Singleton", "class_singleton.html", "class_singleton" ]
    ] ]
];