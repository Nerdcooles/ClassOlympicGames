var class_bucketball_ball =
[
    [ "getPlayer", "class_bucketball_ball.html#a34e17be452a2d03b42bad6f23b6b119d", null ],
    [ "setPlayer", "class_bucketball_ball.html#ac7bad82dcb13cb33af5284f848f6731a", null ]
];