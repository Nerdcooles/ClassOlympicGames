var class_longboard_level_manager =
[
    [ "Score", "class_longboard_level_manager.html#af9c59f2921c7d21120d11c48f5a72784", null ]
];