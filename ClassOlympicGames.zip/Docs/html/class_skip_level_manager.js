var class_skip_level_manager =
[
    [ "Score", "class_skip_level_manager.html#a693988bc8ad3f65295ae2d8f4f63c1cc", null ],
    [ "WAIT_SECS", "class_skip_level_manager.html#a588f4fbd2f69eb2e2d68d67887aa7a1a", null ]
];