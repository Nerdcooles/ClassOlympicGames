var class_summary =
[
    [ "pod", "class_summary.html#a8bc91b6f91d86e28ff3a20219a76bf8a", null ],
    [ "pos", "class_summary.html#a89222217f18b862dc15aafb6bf8e8967", null ]
];