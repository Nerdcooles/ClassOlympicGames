var class_skipper_player =
[
    [ "Initialize", "class_skipper_player.html#abd6b284707226b5a06de11b06b31e7f5", null ],
    [ "Pressed", "class_skipper_player.html#a1c656560d38beceec800adfc3a9309f4", null ],
    [ "Released", "class_skipper_player.html#a1054afa99746b9688e5a3099ccbbc646", null ],
    [ "StartPlayer", "class_skipper_player.html#adc278d8e566551d3020ae7b6a723498f", null ]
];