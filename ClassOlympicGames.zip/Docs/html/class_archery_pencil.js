var class_archery_pencil =
[
    [ "getPlayer", "class_archery_pencil.html#a12397c07baad48c1c2a8a8fb73ef5041", null ],
    [ "setPlayer", "class_archery_pencil.html#aa6d910b462e7ff995f57979d7401d606", null ]
];