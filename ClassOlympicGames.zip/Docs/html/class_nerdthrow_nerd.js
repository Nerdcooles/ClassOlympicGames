var class_nerdthrow_nerd =
[
    [ "Player", "class_nerdthrow_nerd.html#aab2a2e0cdefdada23d3187913b95775c", null ],
    [ "Shooted", "class_nerdthrow_nerd.html#a2ee3f1a5d2a60168d4c9a7f7833d422e", null ],
    [ "StartPt", "class_nerdthrow_nerd.html#a4f4108964d148dcda74fc5d046d1d651", null ]
];