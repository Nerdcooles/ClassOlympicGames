var class_nerd =
[
    [ "Player", "class_nerd.html#a6101c066f392a2c68b5782507d51c541", null ],
    [ "Shooted", "class_nerd.html#a7cc834a94d0e95dc56ef7fa3655691e1", null ],
    [ "StartPt", "class_nerd.html#ab63b8c7b76822d2cfab203396b91eeba", null ]
];