var class_music_manager =
[
    [ "songs", "class_music_manager.html#a1dc8ec39ca34caf1c8761589e24004c1", null ],
    [ "MenuClip", "class_music_manager.html#a696a71c1334a8a96d9e2686841f7b17f", null ],
    [ "Source", "class_music_manager.html#af51ef10e7ad8e38298de3592aeb46f80", null ]
];