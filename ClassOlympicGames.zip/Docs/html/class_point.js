var class_point =
[
    [ "Ammount", "class_point.html#ac578d6bfb9fd3a1b786d9cade338dbea", null ],
    [ "Time", "class_point.html#ac6c31bd283381090f833fafc42e1df10", null ]
];