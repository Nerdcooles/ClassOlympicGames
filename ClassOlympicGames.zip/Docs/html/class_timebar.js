var class_timebar =
[
    [ "setPercentage", "class_timebar.html#adc98c431896fff6ed2e222150cdbfe95", null ],
    [ "full_bar", "class_timebar.html#af223e8af7dab877b7a2c7ad2147abd83", null ]
];