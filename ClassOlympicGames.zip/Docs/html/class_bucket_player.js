var class_bucket_player =
[
    [ "endHitted", "class_bucket_player.html#aa9f96a0491513d401d5ab4c5235fbfc6", null ],
    [ "endShooting", "class_bucket_player.html#aa5910adb371e580eb9f30bb52ad695ce", null ],
    [ "Initialize", "class_bucket_player.html#ab466ad87eee552bad78d073a64746d07", null ],
    [ "Pressed", "class_bucket_player.html#abeeaae9af2341b37ea4013df2e03fb0e", null ],
    [ "Released", "class_bucket_player.html#abf16c73f532aaa17296583d01e3f6f46", null ],
    [ "alpha", "class_bucket_player.html#a9793817ba8f488f94cfc924dd39773e8", null ]
];