var class_bucketball_player =
[
    [ "endHitted", "class_bucketball_player.html#a8d4621a7f9c866525e2997e9c5b7690e", null ],
    [ "endShooting", "class_bucketball_player.html#a1ad14f26eaf8d8d874230493b95f4615", null ],
    [ "Initialize", "class_bucketball_player.html#a5c2e3e2f5bed5191d554c747015bff0b", null ],
    [ "Pressed", "class_bucketball_player.html#ada0f58ae73f558180e5d6b76f1387769", null ],
    [ "Released", "class_bucketball_player.html#a7e1f2395445ec3b681599d035f53f552", null ],
    [ "alpha", "class_bucketball_player.html#ab66514b0a50971e725ad575e77ed549b", null ]
];