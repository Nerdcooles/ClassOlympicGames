var class_archery_level_manager =
[
    [ "Score", "class_archery_level_manager.html#a5bc086412142f7c292c8c2742f477e1c", null ]
];