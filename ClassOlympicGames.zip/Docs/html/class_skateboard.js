var class_skateboard =
[
    [ "player", "class_skateboard.html#a99e391b7e67673dc26bb1562a947c74a", null ]
];