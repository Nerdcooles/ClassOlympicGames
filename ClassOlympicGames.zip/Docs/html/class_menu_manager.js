var class_menu_manager =
[
    [ "Award", "class_menu_manager.html#a9adb328befdf2ba56205dc539f1d3923", null ],
    [ "Credits", "class_menu_manager.html#a31aa0a50fb627a085a1adfa8170238ba", null ],
    [ "LevelOver", "class_menu_manager.html#a873817f42e06561bdbc9cd93fb4a5a30", null ],
    [ "NewGame", "class_menu_manager.html#a89a88917a40426e839630dcb540b2f8c", null ],
    [ "NextLevel", "class_menu_manager.html#afc3a60e4b9b1cbfdfd8e8c80f399cec1", null ],
    [ "SelectLevel", "class_menu_manager.html#a70ee75c63017cbadad9a47038c92a9bc", null ],
    [ "SelectMode", "class_menu_manager.html#a892fd7985f8a3c89d44ffd0b3b00daa8", null ],
    [ "SelectNumber", "class_menu_manager.html#a3f518204d78f554a4f8d3bc9210ce598", null ],
    [ "SelectPlayer", "class_menu_manager.html#a121b304743425481b4736b81baf2e637", null ],
    [ "StartGame", "class_menu_manager.html#a643532ea9a4c2080a76b1dae7dcca072", null ],
    [ "StartHome", "class_menu_manager.html#a8aac2393e6751c8681bc4e1b0dffd296", null ],
    [ "StartLevel", "class_menu_manager.html#ab5e031710d6da1a72610330f256943b6", null ],
    [ "Summary", "class_menu_manager.html#a9c41c081ffbaa0f1fc88bb2be5948053", null ]
];