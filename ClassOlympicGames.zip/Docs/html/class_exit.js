var class_exit =
[
    [ "No", "class_exit.html#a6134a21ed6093d375fb3221b1cd5d763", null ],
    [ "Yes", "class_exit.html#a4dd806e45b69d5a46b13bb16a0e6f18b", null ]
];