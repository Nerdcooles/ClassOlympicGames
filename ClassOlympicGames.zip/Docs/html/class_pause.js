var class_pause =
[
    [ "Continue", "class_pause.html#afc9114b137ef0f1d58d5b3a0b28d006e", null ],
    [ "Exit", "class_pause.html#ac74d2dc9cbeb4cbfdad27ac9b51513e0", null ],
    [ "MainMenu", "class_pause.html#a2e3fcd582ee2b0298b2f454e40957f0f", null ],
    [ "Restart", "class_pause.html#a442cdab5d2ff534ceb59e0a0f1646370", null ],
    [ "Tutorial", "class_pause.html#a424e38237ab310b9e0741a1a97415ae4", null ]
];