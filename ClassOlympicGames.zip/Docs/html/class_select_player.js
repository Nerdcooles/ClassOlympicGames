var class_select_player =
[
    [ "Select", "class_select_player.html#a90636b2052c744ee6d07977d405682d2", null ]
];