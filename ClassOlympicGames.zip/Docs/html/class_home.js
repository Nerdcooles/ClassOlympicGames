var class_home =
[
    [ "Credits", "class_home.html#a2a7194ab46e0816bf14f08aa1bb38aed", null ],
    [ "StartGame", "class_home.html#adc4045d04cc5d69cfe542b32f2823c2d", null ]
];