var class_singleton =
[
    [ "OnDestroy", "class_singleton.html#a81a4ea792b927aeae3f52c1e0d2036af", null ],
    [ "Instance", "class_singleton.html#a54103e8475b2a352ee759d5732307534", null ]
];