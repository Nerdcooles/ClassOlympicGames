var class_bucket_ball =
[
    [ "getPlayer", "class_bucket_ball.html#abe6e0f11fdef7f3d5cd7fdf3d4cc41d7", null ],
    [ "setPlayer", "class_bucket_ball.html#a901c1334f46dffe3a105781fb78fd7e2", null ]
];