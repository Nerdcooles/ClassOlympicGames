var dir_320a9080b4b554e783924cabc377c487 =
[
    [ "LongLevelManager.cs", "_long_level_manager_8cs.html", [
      [ "LongLevelManager", "class_long_level_manager.html", "class_long_level_manager" ]
    ] ],
    [ "Skateboard.cs", "_skateboard_8cs.html", [
      [ "Skateboard", "class_skateboard.html", "class_skateboard" ]
    ] ],
    [ "SkatePlayer.cs", "_skate_player_8cs.html", [
      [ "SkatePlayer", "class_skate_player.html", "class_skate_player" ]
    ] ]
];