var class_arteachery_pencil =
[
    [ "getPlayer", "class_arteachery_pencil.html#ab6ad79f08ee6f48c3b3e6969829309b9", null ],
    [ "setPlayer", "class_arteachery_pencil.html#a10e72f516e3a98205ca46914cb1c93a5", null ]
];