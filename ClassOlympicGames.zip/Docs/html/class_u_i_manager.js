var class_u_i_manager =
[
    [ "getButton", "class_u_i_manager.html#a3d6ce2a9e9851404aa2903f73f83be65", null ],
    [ "score", "class_u_i_manager.html#a89fabb518c977b8cf58ab549c862c0fb", null ],
    [ "SceneHeight", "class_u_i_manager.html#a7dceb5215d0de8d34c2faac9264f0ea5", null ],
    [ "SceneWidth", "class_u_i_manager.html#aed9cef0a1d7274f6c1c81af78435c573", null ]
];