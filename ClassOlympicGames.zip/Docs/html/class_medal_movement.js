var class_medal_movement =
[
    [ "FallDown", "class_medal_movement.html#a020cc35076c157d8d64f276121b0c26e", null ],
    [ "FinalPosition", "class_medal_movement.html#aede8f7fbedd831b0f3d7431cb61f3066", null ]
];