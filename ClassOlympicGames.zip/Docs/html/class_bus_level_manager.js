var class_bus_level_manager =
[
    [ "Score", "class_bus_level_manager.html#a36bb5b79a596e59e8f6dfefdd3247a39", null ],
    [ "WAIT_SECS", "class_bus_level_manager.html#a9ed1591d87088d216cfcf6337b6cdbc5", null ]
];